# preference.py
import json
from langchain_google_genai import ChatGoogleGenerativeAI
from utils import extract_json
from bson import ObjectId
from mongodb_utils import preferences_collection,forms_collection  # 從這裡取得連線設定
from typing import Any, Dict, Optional, List, Set
from pymongo import ReturnDocument

# 明確指定 collection = form_test




# 🔖 偏好分析 Prompt
PREF_PROMPT = """
你是一個旅遊偏好分析師，請從使用者的發言中提取他們的偏好與不喜歡的點，格式如下：
{{"prefer": [...], "avoid": [...]}}

使用者發言：
{input}
"""

# 🧠 用 Gemini 擷取偏好
def extract_preferences_from_text(text: str) -> dict:
    llm = ChatGoogleGenerativeAI(model="gemini-1.5-pro")
    prompt = PREF_PROMPT.format(input=text)
    print("🧠 呼叫 prompt:\n", prompt)
    response = llm.invoke(prompt).content
    print("📩 Gemini 回應：", response)

    extracted = extract_json(response)
    if extracted and isinstance(extracted, dict):
        return {
            "prefer": list(set(extracted.get("prefer", []))),
            "avoid": list(set(extracted.get("avoid", [])))
        }
    return {"prefer": [], "avoid": []}

# 💾（可選）一次性覆蓋所有資料
# def save_user_preferences(data: dict):
    

def upsert_user_preference(
    user_id: str,
    prefer_add: Optional[List[str]] = None,   # 要新增到 prefer 的字
    avoid_add: Optional[List[str]] = None,    # 要新增到 avoid 的字
    trip_id: Optional[str] = None,            # None=全域偏好；有值=某個行程的偏好
) -> Dict[str, Any]:
    """
    目的：增量合併偏好，不洗掉既有資料。
    - 用 $addToSet + $each 加入新詞（天然去重）
    - 用 $pull 從對側移除互斥詞（確保同一詞不會同時在 prefer/avoid）
    - 可選擇性地從 prefer/avoid 移除一些詞
    - upsert=True：若文件不存在會自動建立
    """
    
    update: Dict[str, Any] = {}
    add_to_set: Dict[str, Any] = {}
    pull: Dict[str, Any] = {}

    prefer_add = set(prefer_add or [])
    avoid_add  = set(avoid_add or [])

    # 互斥：新增到 prefer 的詞，先從 avoid 移除；反之亦然
    update = {}
    pull = {}
    add_to_set = {}

    # --- 先確保父節點存在 ---
    # 若此 user 文件不存在就建一個空 trips
    preferences_collection.update_one(
        {"user_id": user_id},
        {"$setOnInsert": {"trips": {}}},
        upsert=True,
    )
    # 若該 trip 子文件還不存在就建空結構
    preferences_collection.update_one(
        {"user_id": user_id, f"trips.{trip_id}": {"$exists": False}},
        {"$set": {f"trips.{trip_id}": {"prefer": [], "avoid": []}}}
    )

    # --- 建 pull（互斥移除） ---
    if prefer_add:
        pull[f"trips.{trip_id}.avoid"] = {"$in": list(prefer_add)}
    if avoid_add:
        pull[f"trips.{trip_id}.prefer"] = {"$in": list(avoid_add)}
    if pull:
        update["$pull"] = pull

    # --- 建 addToSet（去重追加） ---
    if prefer_add:
        add_to_set[f"trips.{trip_id}.prefer"] = {"$each": list(prefer_add)}
    if avoid_add:
        add_to_set[f"trips.{trip_id}.avoid"] = {"$each": list(avoid_add)}
    if add_to_set:
        update["$addToSet"] = add_to_set

    # 沒有任何變更就回傳現況
    if not update:
        return preferences_collection.find_one({"user_id": user_id}) or {}

    # 單筆更新（注意：只用 user_id 當查詢條件）
    doc = preferences_collection.find_one_and_update(
        {"user_id": user_id},
        update,
        upsert=True,
        return_document=ReturnDocument.AFTER,  # 不要寫 True
    )
    return doc


# 📂 載入所有偏好（修正版）
def load_user_preference(user_id: str, trip_id: str | None = None) -> dict:
    """
    讀整個行程的合併偏好（跨使用者彙總）。
    - 先對每位使用者：把 trips["_global"] 與 trips[trip_id] 合併（行程優先）
    - 再把所有人的 prefer/avoid 彙總
    - 回傳 {"prefer":[...], "avoid":[...]}，互斥處理完成
    """
    query = {}

    # 先把 form 取出
    form_doc = forms_collection.find_one(
        {"trip_id": trip_id},
        {"_id": 0, "members.user_id": 1, "leader_id": 1, "preferences": 1, "exclude": 1}
    ) or {}

    # 取出成員 user_id（若沒成員就回退用 leader_id）
    user_chains = [m.get("user_id") for m in form_doc.get("members", []) if m.get("user_id")]
    if not user_chains and form_doc.get("leader_id"):
        user_chains = [form_doc["leader_id"]]

    print("👥 成員 IDs:", user_chains)

    # 只抓有這個 trip 的用戶，或至少有 trips 欄位
    query[f"trips.{trip_id}"] = {"$exists": True}

    cursor = preferences_collection.find(query, {"_id": 0, "user_id": 1, "trips": 1})

    agg_prefer, agg_avoid = set(), set()

    for doc in cursor:
        trips = (doc.get("trips") or {})
        g = trips.get("_global", {}) or {}
        t = trips.get(trip_id, {}) or {}

        g_prefer, g_avoid = set(g.get("prefer", []) or []), set(g.get("avoid", []) or [])
        t_prefer, t_avoid = set(t.get("prefer", []) or []), set(t.get("avoid", []) or [])

        # 這位使用者內部合併（行程優先）
        u_prefer = (g_prefer | t_prefer) - (g_avoid | t_avoid)
        u_avoid  = (g_avoid  | t_avoid)  - u_prefer

        # 彙總
        agg_prefer |= u_prefer
        agg_avoid  |= u_avoid

    # 最後做一次全域互斥淨化
    agg_prefer -= agg_avoid
    agg_avoid  -= agg_prefer

    return {"prefer": sorted(agg_prefer), "avoid": sorted(agg_avoid)}




# 高層主題（你之後只在 prompt / GM 查詢用這些）
THEMES = {
    "表演藝術": {"live", "音樂會", "演唱會", "表演", "劇場", "舞台", "街頭藝人", "舞蹈", "跳舞", "DJ", "夜店", "KTV", "唱歌"},
    "藝文/攝影": {"攝影", "展覽", "美術館", "設計", "文創", "藝文", "打卡", "網美"},
    "文化歷史": {"古蹟", "廟宇", "歷史", "博物館", "老街", "人文"},
    "夜生活":   {"酒吧", "調酒", "live house", "夜店", "KTV", "深夜", "宵夜", "夜市"},
    "咖啡/下午茶": {"咖啡", "咖啡廳", "甜點", "下午茶", "手沖"},
    "自然戶外": {"公園", "步道", "海景", "河景", "親水", "日落", "夕陽", "山景"},
    "運動/水域": {"游泳", "潛水", "衝浪", "獨木舟", "SUP", "爬山", "慢跑", "單車"},
    "美食在地": {"在地小吃", "小吃", "市場", "夜市", "早午餐", "排隊名店"},
    "親子友善": {"親子", "育兒", "兒童", "親子友善"},
}

def normalize_preferences(prefer:list[str], avoid:list[str]) -> dict:

    """把偏好中的單詞對應到主題，之後再查詢替代方案時才不會太侷限 """

    prefer = {t.strip().lower() for t in prefer}
    avoid  = {t.strip().lower() for t in avoid}

    def hit_theme(term:str, keywords:set[str]) -> bool:
        return any(k in term for k in keywords)

    prefer_themes, avoid_themes = set(), set()

    for term in prefer:
        for theme, kws in THEMES.items():
            if hit_theme(term, {k.lower() for k in kws}):
                prefer_themes.add(theme)

    for term in avoid:
        for theme, kws in THEMES.items():
            if hit_theme(term, {k.lower() for k in kws}):
                avoid_themes.add(theme)

    # 互斥：若同時命中，偏好優先或依你規則處理
    avoid_themes -= prefer_themes

    return {
        "prefer_themes": sorted(prefer_themes),
        "avoid_themes": sorted(avoid_themes),
        "raw_prefer": sorted(prefer),
        "raw_avoid": sorted(avoid),
    }
