"""
chat_manager.py — 精排版（PEP 8）

整理項目：
- 移除未使用的 import / 小函式。
- 統一字串與縮排、行長、空白行。
- 保留你既有的邏輯與註解，不更動功能。
- 針對可能的魔法字串/硬編碼標註 TODO。

依賴：mongodb_utils / optimizer / place_* / preference / utils
"""
from __future__ import annotations

import json
import os
from datetime import date, datetime
from typing import Any, Dict, List, Optional

from langchain.chains import ConversationChain
from langchain.memory import ConversationBufferMemory
from langchain.schema import messages_from_dict, messages_to_dict
from langchain_google_genai import ChatGoogleGenerativeAI

from mongodb_utils import get_trip_by_id, forms_collection, trips_collection
from optimizer import build_plan_index
from place_gmaps import gm_alternatives, search_candidates  # 保留以供擴充
from place_new import find_alternative_places_for_rec
from preference import load_user_preference, normalize_preferences
from utils import extract_json


# =========================
# 常數與全域變數
# =========================

# 以今日（台灣）字串做提示/展示（目前僅保留，必要時可用）
TODAY_STR = date.today().strftime("%Y年%m月%d日")

# ⚠️ TODO：不要在程式中硬編碼金鑰，改用系統環境或密鑰管理。
os.environ["GOOGLE_API_KEY"] = os.environ.get(
    "GOOGLE_API_KEY", "AIzaSyD--xrfytwcRt6aGzCnvLauVz-JDmV5GOA"
)

# 記憶體資料夾
MEMORY_FOLDER = "memories"
os.makedirs(MEMORY_FOLDER, exist_ok=True)

# 使用者對話鏈（每位使用者一個 ConversationChain）
user_chains: Dict[str, ConversationChain] = {}

# 最近分析結果（如需快取/展示可用）
last_analysis: Dict[str, Any] = {}

# 待新增地點暫存（視工作流程而定）
pending_add_location: Dict[str, Any] = {}


# =========================
# 工具函式
# =========================

def _safe_to_str_list(items: Any) -> List[str]:
    """將輸入轉為字串列表（過濾空值）。"""
    out: List[str] = []
    if isinstance(items, (list, tuple, set)):
        for x in items:
            if x is None:
                continue
            out.append(str(x))
    elif items:
        out.append(str(items))
    return out


# =========================
# 記憶體處理：載入 / 儲存 / 取得使用者鏈
# =========================

def load_memory(user_id: str):
    """從記憶檔載入 LangChain messages。若檔案不存在則回傳空列表。"""
    path = os.path.join(MEMORY_FOLDER, f"memory_{user_id}.json")
    if os.path.exists(path):
        print(f"🔍 載入記憶檔案：{path}")
        with open(path, "r", encoding="utf-8") as f:
            return messages_from_dict(json.load(f))
    print(f"⚠️ 找不到記憶檔案：{path}")
    return []


def save_memory(user_id: str, messages):
    """將 LangChain messages 儲存為 JSON。"""
    path = os.path.join(MEMORY_FOLDER, f"memory_{user_id}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(messages_to_dict(messages), f, ensure_ascii=False, indent=2)
    print(f"💾 已儲存記憶：{path}")


def get_user_chain(user_id: str) -> ConversationChain:
    """取得（或初始化）該使用者的 ConversationChain。"""
    if user_id not in user_chains:
        llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-pro",
            temperature=0.7,
            max_tokens=1024,
        )
        memory = ConversationBufferMemory(return_messages=True, k=50)

        # 復原歷史訊息（過濾掉包含「今天是20」的訊息）
        all_msgs = load_memory(user_id)
        filtered = [m for m in all_msgs if "今天是20" not in getattr(m, "content", "")]
        memory.chat_memory.messages = filtered

        chain = ConversationChain(llm=llm, memory=memory, verbose=False)
        user_chains[user_id] = chain
    return user_chains[user_id]


def update_and_save_memory(user_id: str, chain: ConversationChain) -> None:
    """將 chain 的記憶體內容持久化到檔案。"""
    save_memory(user_id, chain.memory.chat_memory.messages)


# =========================
# 行程：渲染/展示（鏈結串列 days/head_id/next_id）
# =========================

def display_trip_by_trip_id(trip_id: str) -> str:
    """
    依據 MongoDB trips_collection 的新結構（含 days/head_id/next_id），
    將行程轉成可讀文字。

    結構假設：
    - trip.days: List[{day:int, date:str, city:str, head_id:str}]
    - trip.nodes: List[{node_id:str, slot:str, start:str, end:str, places:[{name,stay_minutes,rating,address}], next_id:str}]
    """
    trip = trips_collection.find_one({"trip_id": trip_id})
    if not trip:
        return "❌ 查無行程"

    title: str = trip.get("title", "未命名")
    start_date: str = trip.get("start_date") or ""
    locations: List[str] = trip.get("locations") or []

    days_meta: List[Dict[str, Any]] = trip.get("days", []) or []
    nodes: List[Dict[str, Any]] = trip.get("nodes", []) or []
    if not nodes or not days_meta:
        return "❌ 查無行程（缺少 days 或 nodes）"

    node_map: Dict[str, Dict[str, Any]] = {n.get("node_id"): n for n in nodes}

    end_date = ""
    try:
        sorted_days = sorted(days_meta, key=lambda d: d.get("day", 0))
        if sorted_days:
            end_date = sorted_days[-1].get("date") or ""
    except Exception:
        sorted_days = days_meta

    header_lines = [
        f"📌 行程名稱：{title}",
        f"📅 日期：{start_date}" + (f" 至 {end_date}" if end_date else ""),
        (f"🗺️ 城市：{'、'.join(locations)}" if locations else ""),
        "📍 每日行程安排：",
    ]
    header = "\n".join([ln for ln in header_lines if ln.strip()])

    out_lines: List[str] = [header, ""]

    for d in sorted_days:
        day_no = d.get("day")
        date_str = d.get("date") or ""
        city = d.get("city") or ""
        head_id = d.get("head_id")

        out_lines.append(f"=== Day {day_no} · {city}（{date_str}） ===")

        if not head_id:
            out_lines.append("（此日未安排）")
            out_lines.append("")
            continue

        curr = head_id
        visited: set[str] = set()
        while curr:
            if curr in visited:
                out_lines.append(f"⚠️ 發現循環連結（{curr}），中止此日列表")
                break
            visited.add(curr)

            node = node_map.get(curr)
            if not node:
                out_lines.append(f"⚠️ 找不到節點：{curr}")
                break

            slot = node.get("slot", "")
            start = node.get("start", "??:??")
            end = node.get("end", "??:??")
            out_lines.append(f"🕒 {slot}  {start}–{end}")

            for p in (node.get("places") or []):
                name = p.get("name", "未命名地點")
                stay = p.get("stay_minutes")
                rating = p.get("rating")
                address = p.get("address")

                metas: List[str] = []
                if stay:
                    metas.append(f"{stay}分")
                if rating:
                    metas.append(f"⭐ {rating}")
                meta_text = f"（{'｜'.join(metas)}）" if metas else ""
                out_lines.append(f"  • {name}{meta_text}")
                if address:
                    out_lines.append(f"    📍 {address}")

            curr = node.get("next_id")

        out_lines.append("")

    return "\n".join(out_lines).rstrip()


# =========================
# 候選景點驗證（Google Maps）
# =========================

def verify_alternative_places(alternative_places: List[str]) -> List[str]:
    """
    使用 Google Maps API 驗證替代景點是否存在，
    回傳驗證成功（並以官方名稱校正後）的景點清單（最多 3 個）。
    """
    try:
        from place_util import search_places_by_tag  # 延遲載入避免循環依賴

        verified: List[str] = []
        for place in alternative_places or []:
            if not place or not isinstance(place, str):
                continue
            results = search_places_by_tag(place.strip())
            if results:
                verified_name = results[0].get("name", place.strip())
                verified.append(verified_name)
                print(f"✅ 驗證成功：{place} -> {verified_name}")
            else:
                print(f"❌ 驗證失敗：{place} (Google Maps 找不到)")
        return verified[:3]
    except Exception as e:
        print(f"❌ verify_alternative_places 發生錯誤：{e}")
        return []


# =========================
# 偏好分析（整合 LLM 與候選搜尋）
# =========================

def analyze_active_users_preferences(
    user_chains: Dict[str, ConversationChain], trip_id: str
) -> List[Dict[str, Any]]:
    """
    分析行程偏好流程：
    1) 取得行程（文字 + 結構）
    2) 載入此行程聚合偏好
    3) 集結聊天文字（限制 2k 字）
    4) 正規化偏好給 LLM
    5) 建立行程白名單索引，限制 LLM 只能引用 ori_place
    6) 呼叫 LLM 生成建議（modify/add/delete），並以 Google Maps 搜尋候選地點
    7) 回傳整理後結果
    """
    try:
        trip_text = display_trip_by_trip_id(trip_id)
        print("✅ trip_text:", trip_text)
        if not trip_text or "❌ 查無行程" in trip_text:
            print("❌ 找不到行程資料，無法進行分析")
            return []

        trip_doc = get_trip_by_id(trip_id)
        if not isinstance(trip_doc, dict):
            print("❌ get_trip_by_id 沒拿到 dict")
            return []

        trip_preferences = load_user_preference(None, trip_id)
        all_prefer = trip_preferences.get("prefer", []) or []
        all_avoid = trip_preferences.get("avoid", []) or []
        print(
            f"🔍 行程 {trip_id} 的合併偏好：\n   喜歡：{all_prefer}\n   避免：{all_avoid}"
        )

        combined_text = ""
        for _, chain in user_chains.items():
            for msg in chain.memory.chat_memory.messages:
                if getattr(msg, "type", "") in ("human", "ai"):
                    combined_text += f"{msg.type}: {msg.content}\n"
        if not combined_text.strip():
            combined_text = "無聊天紀錄"

        prefer_list = (
            "\n".join([f"- {p}" for p in sorted(set(_safe_to_str_list(all_prefer)))])
            or "- 無特定偏好"
        )
        avoid_list = (
            "\n".join([f"- {p}" for p in sorted(set(_safe_to_str_list(all_avoid)))])
            or "- 無特定避免項目"
        )
        preference = normalize_preferences(prefer_list, avoid_list)
        preference_summary = json.dumps(preference, ensure_ascii=False, indent=2)

        plan_index = build_plan_index(trip_doc)
        plan_index_json = json.dumps(plan_index, ensure_ascii=False)
        print("看一下白名單的內容", plan_index)

        GEO_GUARD_TEXT = """
- 地理約束（必守）：
  1) 不得跨縣市/行政區；新景點必須落在與該日主要城市（days.city）一致的行政區內。
  2) 與該時段節點（slot node）或當日重心的直線距離 <= {max_km} 公里，否則不建議新增，優先建議 delete。
  3) 優先同一行政區內的相鄰商圈；不可推薦跨區連跳（例如高雄當日卻推台南）。
"""

        PROMPT_TEMPLATE = r"""
請輸出唯一一個 JSON 陣列（不要任何解說文字）。每筆物件結構如下：
{
  "type": "modify" | "add" | "delete",
  "day": <int>,
  "slot": "上午" | "中午" | "下午" | "晚上" | "整天" | "其他",
  "ori_place": "需要更改的原始景點（必須從白名單對應時段中擇一；若該時段本來就沒有地點才可空字串）",
  "ori_place_id": "需要更改的原始景點的place_id（必須從白名單對應時段中擇一；若該時段本來就沒有地點才可空字串）",
  "reason": {
    "summary": "<80–140 字，避免套話，避免重複詞彙，必須具體可驗證>",
    "evidence": [
      "<列 2–4 條具體依據，必須來自行程/偏好/營業時段/動線/時長/評分/主題衝突等；可引用 ori_place 與時段>",
      "<例如：『晚上 17:00–21:00 連續兩個吃的，缺少夜間體驗類型』、『偏好有「文藝/現場音樂」，現有點皆為餐食』>"
    ],
    "benefits": [
      "<這樣改的好處（1–2 條）：時間銜接/移動距離/主題匹配/評價門檻/排隊風險等>",
      "<避免『更好玩』『更有趣』等空話>"
    ],
    "rationale_tags": [
      "動線優化" | "主題匹配" | "評價門檻" | "營業時段" | "人潮風險" | "天氣因素" | "預算控制"
    ]
  },
  "target": {
    "by_slot": true,
    "by_place": { "contains": ["<可檢索的主題關鍵字，不得是具名地點>", "..."] }
  },
  "near_hint": "slot_node" | "prev_node" | "next_node" | null
}

嚴格規範：
- 嚴禁在任何欄位輸出具名的「新」景點；`ori_place` 只能引用原行程白名單中的名稱。
- 每筆建議的 `reason.summary` 必須是不同角度（例如：一筆講主題衝突、一筆講動線/時長、一筆講營業時段/人潮），不可重複用語。
- `evidence` 至少 2 條、`benefits` 至少 1 條，且都要可被行程內容或偏好驗證。
- 若偏好含「唱歌/跳舞」等字面娛樂詞，請抽象成可檢索的文化/藝術主題（如「現場音樂酒吧」「小型展演」「城市散步路廊」「文青咖啡」），避免直接出現「KTV」「夜店」等過度直白詞。
- 產出 2–4 筆建議即可；優先挑選「最需要調整」的時段與點。

=== 使用者偏好（已去重與互斥） ===
<<PREF>>

=== 行程白名單（嚴格照此索引挑選 ori_place，禁止憑空捏造） ===
<<PLAN_INDEX>>

=== 目前行程內容（人類可讀版） ===
<<TRIP_TEXT>>

=== 最近聊天重點 ===
<<CHAT>>

<<GEO_GUARD>>
"""
        prompt = (
            PROMPT_TEMPLATE.replace("<<PREF>>", preference_summary.strip())
            .replace("<<PLAN_INDEX>>", plan_index_json)
            .replace("<<TRIP_TEXT>>", trip_text)
            .replace("<<CHAT>>", combined_text[:2000])
            .replace("<<GEO_GUARD>>", GEO_GUARD_TEXT.format(max_km=5))
        )

        print("🧠 讓 AI 自動判斷旅遊地點，準備分析...")
        print(f"📝 Prompt 長度：{len(prompt)} 字元")

        analysis_llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-pro",
            model_kwargs={"location": "us-central1"},
            temperature=0.2,
        )
        response_text = analysis_llm.invoke(prompt).content
        print("📩 Gemini 回應原始文字：\n", response_text)

        recs = extract_json(response_text)
        if not isinstance(recs, list):
            print("⚠️ LLM 回覆不是陣列")
            return []

        processed: List[Dict[str, Any]] = []
        for rec in recs:
            if not isinstance(rec, dict):
                continue
            if rec.get("type") not in ("add", "delete", "modify"):
                continue

            out: Dict[str, Any] = {
                "type": rec["type"],
                "day": rec.get("day"),
                "slot": rec.get("slot"),
                "ori_place": rec.get("ori_place", ""),
                "ori_place_id": rec.get("ori_place_id", ""),
                "reason": rec.get("reason", {}),
                "target": rec.get("target", {}),
                "near_hint": rec.get("near_hint"),
            }

            if rec["type"] in ("modify", "add"):
                cand = find_alternative_places_for_rec(
                    rec=rec, trip_doc=trip_doc, default_radius=2000
                )
                out["new_places"] = cand or []
                if not cand and rec["type"] == "modify":
                    out["note"] = "未找到符合條件的候選地點"

            processed.append(out)

        print(f"✅ 成功解析 {len(processed)} 個建議")

        type_counts: Dict[str, int] = {}
        for r in processed:
            type_counts[r["type"]] = type_counts.get(r["type"], 0) + 1
        print(f"📊 建議類型統計：{type_counts}")

        for i, r in enumerate(processed, 1):
            if r["type"] in ("modify", "add"):
                print(
                    f"   建議 {i}：{r['type']} - ori={r.get('ori_place','')} -> "
                    f"{len(r.get('new_places', []))} 個候選 (Day {r.get('day')}, {r.get('slot')})"
                )
            else:
                print(
                    f"   建議 {i}：{r['type']} - ori={r.get('ori_place','')} "
                    f"(Day {r.get('day')}, {r.get('slot')})"
                )

        return processed

    except Exception as e:
        print(f"❌ analyze_active_users_preferences 發生錯誤：{e}")
        import traceback

        traceback.print_exc()
        return []


# =========================
# 意圖偵測：是否想新增景點
# =========================
from typing import Dict, Any
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.pydantic_v1 import BaseModel, Field

class AddLocationIntent(BaseModel):
    add_location: bool = Field(..., description="是否明確表達要新增景點")
    place_name: str = Field("", description="景點名稱，若無則空字串")

INTENT_SYSTEM = (
    "你是一位旅遊行程意圖分類器。"
    "輸入是一句使用者訊息；輸出必須是 JSON 物件，且只包含 add_location 與 place_name 兩個欄位。"
)

def detect_add_location_intent(text: str) -> Dict[str, Any]:
    llm = ChatGoogleGenerativeAI(
        model="gemini-1.5-pro",
        temperature=0,
        # 關鍵：要求模型只產生 JSON
        model_kwargs={"response_mime_type": "application/json"},
    )

    # 讓模型直接輸出結構化結果（LangChain 會自動驗證+解析）
    parser_llm = llm.with_structured_output(AddLocationIntent)

    prompt = (
        f"{INTENT_SYSTEM}\n"
        f"請依據訊息判斷是否有『新增景點』意圖，"
        f"若提到具體地名則填入 place_name，否則給空字串。\n"
        f"使用者訊息：{text}"
    )

    try:
        result: AddLocationIntent = parser_llm.invoke(prompt)  # 已是 Pydantic 物件
        return {"add_location": bool(result.add_location), "place_name": result.place_name.strip()}
    except Exception as e:
        print(f"[intent] structured_output 失敗：{e}")
        return {"add_location": False, "place_name": ""}

# =========================
# 決定新地點放置到哪一天/時段
# =========================

def decide_location_placement(user_id: str, trip_id: str, place: str) -> Dict[str, Any]:
    """
    根據行程、使用者偏好與聊天紀錄，決定「place」最適合安排的 Day / 時段。

    回傳格式：{"day": int|None, "period": "上午"|"下午"|None}
    """
    try:
        llm = ChatGoogleGenerativeAI(model="gemini-1.5-pro", temperature=0.3)

        # 嘗試從全域 user_chains 取得聊天紀錄（優先），避免把 DB 的 raw doc 誤當 chain 使用
        chat_history = ""
        if user_id in user_chains:
            for msg in user_chains[user_id].memory.chat_memory.messages:
                if getattr(msg, "type", "") in ("human", "ai"):
                    chat_history += f"{msg.type}: {msg.content}\n"
        else:
            try:
                doc = forms_collection.find_one({"trip_id": trip_id})
                if isinstance(doc, dict):
                    # 若你有把 chat history 存到某欄位（例如 doc["chat"]），在這裡串起來。
                    # chat_history = "\n".join(doc.get("chat", []))
                    pass
            except Exception:
                pass

        itinerary_text = display_trip_by_trip_id(trip_id)

        all_preferences = load_user_preference()
        user_preferences = (
            all_preferences.get(user_id, {}) if isinstance(all_preferences, dict) else {}
        )
        prefer_str = (
            "、".join(_safe_to_str_list(user_preferences.get("prefer", [])))
            or "無特定偏好"
        )
        avoid_str = (
            "、".join(_safe_to_str_list(user_preferences.get("avoid", [])))
            or "無特定避免項目"
        )

        prompt = f"""
你是一位智慧行程規劃助理。請根據使用者目前的行程、個人偏好和聊天紀錄，判斷最適合將「{place}」這個景點安排在哪一天、哪個時段？

請考慮以下因素：
1. 地理位置的合理性（同區域景點安排在同一天）
2. 行程的鬆緊度（避免過度密集）
3. 使用者的個人偏好

使用者個人偏好：
🧠 喜歡：{prefer_str}
⚠️ 避免：{avoid_str}

目前行程內容：
{itinerary_text}

使用者聊天紀錄（最近片段）：
{chat_history[-1000:]}

請務必只回傳一個符合 JSON Schema 的 JSON 程式碼區塊，不要包含任何額外的文字或說明。
JSON 必須包含在 ```json 和 ``` 之間。

JSON 格式如下：
```json
{{
    "day": 1,
    "period": "上午"
}}
```

如果無法判斷或行程已滿，請回傳：
```json
{{
    "day": null,
    "period": null
}}
```
"""
        print("🧠 Placement Prompt:\n", prompt)
        response = llm.invoke(prompt).content
        print("📩 Gemini Placement 回應（repr）：", repr(response))

        result = extract_json(str(response))
        print(f"🔍 Placement 解析結果：{result}")

        if isinstance(result, dict) and (result.get("day") is not None) and (
            result.get("period") is not None
        ):
            return {"day": result.get("day"), "period": result.get("period")}
        return {"day": None, "period": None}

    except Exception as e:
        print(f"❌ decide_location_placement 發生錯誤：{e}")
        return {"day": None, "period": None}
